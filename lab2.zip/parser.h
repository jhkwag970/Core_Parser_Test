#ifndef PARSER_H
#define PARSER_H

#include "tree.h"


/*
*
* Put headers for parse functions here
*
*/

void scanner(char* filename);
void test_scanner(char* filename);

#endif